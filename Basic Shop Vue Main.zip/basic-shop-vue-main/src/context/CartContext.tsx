import React, { createContext, useContext, useState, useCallback } from "react";
import { CartItem, Cart, Product } from "@/types/shop";

interface CartContextType {
  cart: Cart;
  addProduct: (product: Product) => void;
  updateMenge: (productId: number, menge: number) => void;
  removeItem: (productId: number) => void;
  clearCart: () => void;
  itemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

function recalculate(items: CartItem[]): Cart {
  const updated = items.map((item) => ({
    ...item,
    gesamtpreis: Math.round(item.preis * item.menge * 100) / 100,
  }));
  return {
    items: updated,
    gesamtsumme: Math.round(updated.reduce((sum, i) => sum + i.gesamtpreis, 0) * 100) / 100,
  };
}

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<Cart>({ items: [], gesamtsumme: 0 });

  const addProduct = useCallback((product: Product) => {
    setCart((prev) => {
      const existing = prev.items.find((i) => i.productId === product.id);
      let items: CartItem[];
      if (existing) {
        items = prev.items.map((i) =>
          i.productId === product.id ? { ...i, menge: i.menge + 1 } : i
        );
      } else {
        items = [
          ...prev.items,
          { productId: product.id, name: product.name, preis: product.preis, menge: 1, gesamtpreis: product.preis },
        ];
      }
      return recalculate(items);
    });
  }, []);

  const updateMenge = useCallback((productId: number, menge: number) => {
    if (menge < 1) return;
    setCart((prev) => {
      const items = prev.items.map((i) =>
        i.productId === productId ? { ...i, menge } : i
      );
      return recalculate(items);
    });
  }, []);

  const removeItem = useCallback((productId: number) => {
    setCart((prev) => recalculate(prev.items.filter((i) => i.productId !== productId)));
  }, []);

  const clearCartFn = useCallback(() => {
    setCart({ items: [], gesamtsumme: 0 });
  }, []);

  const itemCount = cart.items.reduce((sum, i) => sum + i.menge, 0);

  return (
    <CartContext.Provider value={{ cart, addProduct, updateMenge, removeItem, clearCart: clearCartFn, itemCount }}>
      {children}
    </CartContext.Provider>
  );
};

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
